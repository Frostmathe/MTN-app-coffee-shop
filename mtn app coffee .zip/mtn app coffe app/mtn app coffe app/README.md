# MTN APP demo

## Get Started

## Step1

install dev dependences

### `npm install`

## Then

Run The app

### `npm start`

N.B dummy login nothing will be saved . 
