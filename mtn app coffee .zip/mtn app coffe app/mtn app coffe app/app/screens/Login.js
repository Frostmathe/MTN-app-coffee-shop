import './App.css';
import { Button, TextField } from '@material-ui/core';
import {Text,View,Button} from 'react-native';

function App() {
  return (
    <div className="App">
      <div className="LoginCard">
      <div className="header">
      <p className="font">Welcome Back</p>
      </div>
      <div
      className="input"
      >
      <TextField
      variant="outlined"
      label="email"
      type="email"
      /> 
      </div>
      
      
      <div
      className="input"
      >
      <TextField
      variant="outlined"
      label="password"
      type="password"
      />
      </div>
      
      <div
      className="button"
      >
      <Button 
      variant="outlined"
      >
      
      <Button onclick="HomeScreen()">Login</Button></Button>
      </div>
    
      <div className="signUp">
      <p>Don't have an account?</p>
      <p className="signUpText" >Sign up</p>
      </div>
      </div>
    </div>
  );
}

export default App;
