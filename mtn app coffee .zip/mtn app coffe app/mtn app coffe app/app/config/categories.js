// list of coffee categories
const categories = [
  {
    id: 1,
    name: "Cappuccino",
  },
  {
    id: 2,
    name: "Espresso",
  },
  { id: 3, name: "Latte" },
  {
    id: 4,
    name: "Flat White",
  },
];

export default categories;
